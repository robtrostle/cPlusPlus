//This is the implementation file f.cpp 
//The interface for the method hello is in the header file f.h.
#include <iostream>
#include <cstdlib>
using namespace std;
#include "f.h"

void f::hello()
{
	cout << "Hello from F! " << endl;
}