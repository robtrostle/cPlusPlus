//This is the header file f.h. This is the interface for the method hello
#pragma once //Header guard. Will only allow header once. 

	namespace f {
		void hello();
	}
	
