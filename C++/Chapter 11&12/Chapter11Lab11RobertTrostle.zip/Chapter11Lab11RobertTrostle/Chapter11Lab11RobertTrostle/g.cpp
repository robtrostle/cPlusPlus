//This is the implementation file g.cpp  
//The interface for the method hello is in the header file g.h.
#include <iostream>
#include <cstdlib>
using namespace std;
#include "g.h"

void g::hello()
{
	cout << "Hello from G! " << endl;
}