//This is the header file g.h. This is the interface for the method hello
#pragma once

namespace g {
	void hello();
}
